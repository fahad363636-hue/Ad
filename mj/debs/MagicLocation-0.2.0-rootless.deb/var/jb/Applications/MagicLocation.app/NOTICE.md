# Attribution

MagicLocation is a new, independent application. It contains no FakeGPS binaries,
license helpers, bundle identifiers, preferences or runtime injection components.

The native `CLSimulationManager` start/stop sequence and the required signing
entitlement are based on the public locsim project by udevs:
https://github.com/udevsharold/locsim
Copyright (c) 2021 udevs. GPL version 3.

MagicLocation source is distributed under GPL-3.0-only. See LICENSE.
