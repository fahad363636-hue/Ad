/* ChatGPT WebKit Guard 0.1.0
 * Experimental workaround for an iOS 16.5.1 WebKit SIGABRT seen in
 * WebCore::CSSLinearGradientValue::createStyleImage / bad_variant_access.
 * Loaded at document start by PoomSmart Polyfills.
 * No network requests; does not read page data or credentials.
 */
(function () {
  'use strict';
  var host = location.hostname.toLowerCase();
  if (host !== 'chatgpt.com' && host !== 'chat.openai.com' &&
      !/\.chatgpt\.com$/.test(host)) return;
  if (window.__MJChatGPTGradientGuard) return;
  window.__MJChatGPTGradientGuard = '0.1.0';

  // A high-priority cascade override avoids resolving fragile gradient
  // colors when ChatGPT triggers layout/style calculations (e.g. scrollHeight).
  // Side effect: some gradients, masks, and decorative icons will disappear.
  var css = [
    'html, html *, html *::before, html *::after {',
    'background-image: none !important;',
    '-webkit-mask-image: none !important;',
    'mask-image: none !important;',
    'border-image-source: none !important;',
    'list-style-image: none !important;',
    '}'
  ].join('');
  var styleId = 'mj-chatgpt-gradient-guard';
  var observing = false;
  function inject() {
    var parent = document.head || document.documentElement;
    if (!parent) return false;
    if (!document.getElementById(styleId)) {
      var el = document.createElement('style');
      el.id = styleId;
      el.type = 'text/css';
      el.textContent = css;
      parent.insertBefore(el, parent.firstChild);
    }
    return true;
  }
  inject();
  // At document-start the HTML element may not exist yet. Observe just until
  // injection succeeds; do not keep an expensive observer on ChatGPT's DOM.
  if (!document.getElementById(styleId) && !observing) {
    observing = true;
    var observer = new MutationObserver(function () {
      if (inject()) observer.disconnect();
    });
    observer.observe(document, {childList:true, subtree:true});
    document.addEventListener('DOMContentLoaded', function () {
      inject();
      observer.disconnect();
    }, {once:true});
  }
})();
